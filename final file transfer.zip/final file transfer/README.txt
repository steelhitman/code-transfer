Add server IP in ip_client file.
Add client IP in ip_server file.
The ip can be found on windows using ipconfig in command prompt(win+r then type cmd).
If you are connected using wifi then find the wifi address. 
If you are connected via ethernet(LAN) then find the ethernet address.
The project works on the same network.
